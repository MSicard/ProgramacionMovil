package com.iteso.sesion5.Constants;

/**
 * Created by Maritza on 04/09/2017.
 */

public class Constants {
    public static final String NAME = "name";
    public static final String PHONE = "phone";
    public static final String BOOK = "book";
    public static final String SPORT = "sport";
    public static final String SCHOLARSHIP = "scholarship";
    public static final String GENDER = "gender";
}
